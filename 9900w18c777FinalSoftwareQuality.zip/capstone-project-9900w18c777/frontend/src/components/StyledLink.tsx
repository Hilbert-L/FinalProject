import styled from "styled-components";

export const StyledLink = styled.a`
  &:hover {
    cursor: pointer;
  }
`;